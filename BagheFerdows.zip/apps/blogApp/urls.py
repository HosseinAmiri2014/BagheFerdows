from django.urls import path
from . import views
from .views import WorkshopListView, WorkshopDetailView


urlpatterns = [
    path('', views.research_home, name='research_home'),
    path('articles/', views.article_list, name='article_list'),
    path('articles/<slug:slug>/', views.article_detail, name='article_detail'),
    path('articles/<slug:slug>/download/', views.download_article_pdf, name='download_article_pdf'),
    path('workshops/', WorkshopListView.as_view(), name='workshop_list'),
    path('workshops/<int:pk>/', WorkshopDetailView.as_view(), name='workshop_detail'),
]