from django.db import models
from django.utils.text import slugify

class Author(models.Model):
    first_name = models.CharField(max_length=100, verbose_name="نام")
    last_name = models.CharField(max_length=100, verbose_name="نام خانوادگی")
    education = models.CharField(max_length=255, verbose_name="تحصیلات", blank=True, null=True)
    job_title = models.CharField(max_length=255, verbose_name="عنوان شغلی", blank=True, null=True)
    email = models.EmailField(unique=True, verbose_name="آدرس ایمیل")
    mobile = models.CharField(max_length=15, verbose_name="شماره موبایل", blank=True, null=True)
    slug = models.SlugField(unique=True, blank=True, null=True, verbose_name="اسلاگ")
    is_active = models.BooleanField(default=True, verbose_name="وضعیت نویسنده")

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(f"{self.first_name}-{self.last_name}")
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.first_name} {self.last_name}"

class ArticleGroup(models.Model):
    name = models.CharField(max_length=50, unique=True, verbose_name="عنوان گروه")

    def __str__(self):
        return self.name

class Article(models.Model):
    title = models.CharField(max_length=255, verbose_name="عنوان مقاله")
    group = models.ForeignKey(ArticleGroup, on_delete=models.CASCADE, verbose_name="گروه مقاله")
    main_image = models.ImageField(upload_to='articles/images/', verbose_name="تصویر اصلی مقاله", null=True, blank=True)
    authors = models.ManyToManyField(Author, verbose_name="نویسندگان")
    slug = models.SlugField(unique=True, blank=True, null=True, verbose_name="اسلاگ")
    short_text = models.TextField(verbose_name="متن کوتاه (خلاصه)")
    abstract = models.TextField(verbose_name="متن چکیده مقاله")
    pdf_file = models.FileField(upload_to='articles/pdfs/', verbose_name="فایل PDF مقاله", null=True, blank=True)
    published_at = models.DateTimeField( blank=True, null=True, verbose_name="تاریخ انتشار")
    is_active = models.BooleanField(default=True, verbose_name="وضعیت مقاله")
    views = models.IntegerField(default=0, verbose_name="تعداد بازدید")

    def __str__(self):
        return self.title

class ArticleGallery(models.Model):
    article = models.ForeignKey(Article, on_delete=models.CASCADE, related_name="gallery", verbose_name="مقاله")
    image = models.ImageField(upload_to='articles/gallery/', verbose_name="تصویر مقاله")

    def __str__(self):
        return f"تصویر مربوط به {self.article.title}"

from django.db import models
from django.utils.text import slugify
from django.utils import timezone

class WorkshopStatus(models.Model):
    STATUS_CHOICES = [
        (1, 'برگزار نشده'),
        (2, 'در حال برگزاری'),
        (3, 'برگزار شده'),
        (4, 'لغو شده'),
    ]
    id = models.IntegerField(choices=STATUS_CHOICES, primary_key=True, verbose_name="کد وضعیت کارگاه")
    title = models.CharField(max_length=50, unique=True, verbose_name="عنوان وضعیت")

    def __str__(self):
        return self.title

    class Meta:
        verbose_name = "وضعیت کارگاه"
        verbose_name_plural = "وضعیت‌ کارگاه‌ها"


class Workshop(models.Model):
    title = models.CharField(max_length=255, verbose_name="عنوان کارگاه")
    main_image = models.ImageField(upload_to='workshops/images/', verbose_name="تصویر اصلی کارگاه", null=True, blank=True)
    date_time = models.DateTimeField( default= timezone.now, verbose_name="تاریخ و زمان برگزاری")
    location = models.CharField(max_length=255, verbose_name="مکان برگزاری")
    instructor = models.CharField(max_length=255, verbose_name="مدرس کارگاه")
    description = models.TextField(verbose_name="اطلاعاتی در مورد کارگاه")
    registration_info = models.TextField(verbose_name="نحوه ثبت نام")
    report = models.TextField(blank=True, null=True, verbose_name="گزارش کارگاه")
    views = models.IntegerField(default=0, verbose_name="تعداد بازدید از گزارش")
    created_at = models.DateTimeField( auto_now=True, null=True, blank=True, verbose_name="تاریخ ثبت")
    is_active = models.BooleanField(default=True, verbose_name="وضعیت (فعال/غیرفعال)")
    status = models.ForeignKey(WorkshopStatus, on_delete=models.CASCADE, null=True, verbose_name="وضعیت کارگاه")

    def __str__(self):
        return self.title

    class Meta:
        verbose_name = "کارگاه"
        verbose_name_plural = "کارگاه‌ها"


class WorkshopGallery(models.Model):
    workshop = models.ForeignKey(Workshop, on_delete=models.CASCADE, related_name="gallery", verbose_name="کارگاه")
    image = models.ImageField(upload_to='workshops/gallery/', verbose_name="تصویر کارگاه")

    def __str__(self):
        return f"تصویر مربوط به {self.workshop.title}"

    class Meta:
        verbose_name = "گالری کارگاه"
        verbose_name_plural = "گالری کارگاه‌ها"
