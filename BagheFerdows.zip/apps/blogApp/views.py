from django.shortcuts import render, get_object_or_404
from django.http import FileResponse, Http404
from .models import Article, Workshop, WorkshopGallery

def research_home(request):
    return render(request, 'blogApp/research_home.html')

def article_list(request):
    articles = Article.objects.filter(is_active=True).order_by('-published_at')
    return render(request, 'blogApp/article_list.html', {'articles': articles})

def article_detail(request, slug):
    article = get_object_or_404(Article, slug=slug, is_active=True)
    return render(request, 'blogApp/article_detail.html', {'article': article})

def download_article_pdf(request, slug):
    article = get_object_or_404(Article, slug=slug, is_active=True)
    if article.pdf_file:
        return FileResponse(article.pdf_file.open('rb'), as_attachment=True, filename=f"{article.title}.pdf")
    else:
        raise Http404("فایل PDF موجود نیست.")

from django.views.generic import ListView, DetailView




class WorkshopListView(ListView):
    model = Workshop
    template_name = 'blogApp/workshop_list.html'
    context_object_name = 'workshops'
    ordering = ['-date_time']
    queryset = Workshop.objects.filter(is_active=True).select_related('status')


class WorkshopDetailView(DetailView):
    model = Workshop
    template_name = 'blogApp/workshop_detail.html'
    context_object_name = 'workshop'

    def get_object(self, queryset=None):
        workshop = super().get_object(queryset)
        workshop.views += 1  
        workshop.save()
        return workshop

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['gallery'] = WorkshopGallery.objects.filter(workshop=self.get_object())
        return context