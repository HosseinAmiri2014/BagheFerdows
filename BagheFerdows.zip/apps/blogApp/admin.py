from django.contrib import admin
from .models import Author, ArticleGroup, Article, ArticleGallery, WorkshopStatus, Workshop, WorkshopGallery

@admin.register(Author)
class AuthorAdmin(admin.ModelAdmin):
    list_display = ('first_name', 'last_name', 'email', 'job_title', 'is_active')
    search_fields = ('first_name', 'last_name', 'email')
    list_filter = ('is_active',)
    prepopulated_fields = {'slug': ('first_name', 'last_name')}

@admin.register(ArticleGroup)
class ArticleGroupAdmin(admin.ModelAdmin):
    list_display = ('id', 'name')
    search_fields = ('name',)

@admin.register(Article)
class ArticleAdmin(admin.ModelAdmin):
    list_display = ('title', 'group', 'published_at', 'is_active', 'views')
    list_filter = ('group', 'is_active', 'published_at')
    search_fields = ('title', 'authors__first_name', 'authors__last_name')
    prepopulated_fields = {'slug': ('title',)}
    filter_horizontal = ('authors',)  # انتخاب نویسندگان به صورت افقی در پنل ادمین
    date_hierarchy = 'published_at'  # فیلتر تاریخ در بالای صفحه مقالات

@admin.register(ArticleGallery)
class ArticleGalleryAdmin(admin.ModelAdmin):
    list_display = ('article', 'image')
    search_fields = ('article__title',)
    


@admin.register(WorkshopStatus)
class WorkshopStatusAdmin(admin.ModelAdmin):
    list_display = ('id', 'title')

@admin.register(Workshop)
class WorkshopAdmin(admin.ModelAdmin):
    list_display = ('title', 'date_time', 'location', 'instructor', 'status', 'is_active', 'views')
    list_filter = ('status', 'is_active', 'date_time')
    search_fields = ('title', 'instructor')
    prepopulated_fields = {'title': ('title',)}

@admin.register(WorkshopGallery)
class WorkshopGalleryAdmin(admin.ModelAdmin):
    list_display = ('workshop', 'image')
    search_fields = ('workshop__title',)

