
from django.shortcuts import render, redirect
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import Group



def register_view(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            group = Group.objects.get(name='کاربر عادی')
            user.groups.add(group)
            login(request, user)
            return redirect('user_panel')
    else:
        form = UserCreationForm()
    return render(request, 'accountingApp/register.html', {'form': form})


def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect('user_panel')
    else:
        form = AuthenticationForm()
    return render(request, 'accountingApp/login.html', {'form': form})


@login_required
def user_panel(request):
    return render(request, 'accountingApp/user_panel.html')
