from django.contrib import admin
from .models import VisitRoute
# Register your models here.
from .models import History, GardenSection,VisitorGroup,VisitRoute,Place, TicketPrice,Message

class VisitRouteAdmin(admin.ModelAdmin):
    list_display=['title', 'route_map', 'route_file']


admin.site.register(History)
admin.site.register(GardenSection)
admin.site.register(VisitorGroup)
admin.site.register(VisitRoute, VisitRouteAdmin)
admin.site.register(Place)
admin.site.register(TicketPrice)
admin.site.register(Message)