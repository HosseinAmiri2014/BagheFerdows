from django import forms
from .models import Message

class MessageForm(forms.ModelForm):
    """ فرم ارسال پیام در صفحه تماس با ما """
   
    class Meta:
        model = Message
        fields = ['name', 'email', 'subject', 'message']
        labels = {
            'name': 'نام و نام خانوادگی',
            'email': 'آدرس ایمیل',
            'subject': 'موضوع پیام',
            'message': 'متن پیام'
        }
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'نام خود را وارد کنید'}),
            'email': forms.EmailInput(attrs={'class': 'form-control', 'placeholder': 'ایمیل خود را وارد کنید'}),
            'subject': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'موضوع پیام'}),
            'message': forms.Textarea(attrs={'class': 'form-control', 'rows': 4, 'placeholder': 'متن پیام خود را بنویسید'}),
        }
