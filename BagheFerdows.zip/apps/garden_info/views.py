from django.shortcuts import render

from django.shortcuts import render, redirect
from .models import History, GardenSection, VisitRoute, VisitorGroup, Place, TicketPrice, Message
from .forms import MessageForm

def history_view(request):
    history = History.objects.last()
    return render(request, 'garden_info/history.html', {'history': history})

def garden_sections_view(request):
    sections = GardenSection.objects.all()
    return render(request, 'garden_info/sections.html', {'sections': sections})

def visit_route_view(request):
    visit_route = VisitRoute.objects.last()
    return render(request, 'garden_info/visit_route.html', {'visit_route': visit_route})

def visit_info_view(request):
    places = Place.objects.all()
    visitor_groups = VisitorGroup.objects.all()
    ticket_prices = TicketPrice.objects.select_related('visitor_group', 'place').all()
    return render(request, 'garden_info/visit_info.html', {
        'places': places,
        'visitor_groups': visitor_groups,
        'ticket_prices': ticket_prices
    })

def contact_view(request):
    if request.method == 'POST':
        form = MessageForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('contact')
    else:
        form = MessageForm()
    return render(request, 'garden_info/contact.html', {'form': form})
