from django.db import models



class History(models.Model):
    title = models.CharField(max_length=255, verbose_name="عنوان")
    description = models.TextField(verbose_name="توضیحات")
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="تاریخ ثبت")

    def __str__(self):
        return self.title

    class Meta:
        verbose_name = "تاریخچه باغ"
        verbose_name_plural = "تاریخچه باغ"
############################################################

class GardenSection(models.Model):
    SECTION_CHOICES = [
        ('museum', 'موزه سینما'),
        ('garden', 'محوطه باغ'),
    ]
    
    name = models.CharField(max_length=255, verbose_name="نام بخش")
    description = models.TextField(verbose_name="توضیحات")
    section_type = models.CharField(max_length=10, choices=SECTION_CHOICES, verbose_name="نوع بخش")
    image = models.ImageField(upload_to='garden_sections/', null=True, blank=True, verbose_name="تصویر")

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = "بخش باغ"
        verbose_name_plural = "بخش‌های باغ"
#########################№##################################
class GardenSection(models.Model):
    SECTION_CHOICES = [
        ('museum', 'موزه سینما'),
        ('garden', 'محوطه باغ'),
    ]
    
    name = models.CharField(max_length=255, verbose_name="نام بخش")
    description = models.TextField(verbose_name="توضیحات")
    section_type = models.CharField(max_length=10, choices=SECTION_CHOICES, verbose_name="نوع بخش")
    image = models.ImageField(upload_to='garden_sections/', null=True, blank=True, verbose_name="تصویر")

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = "بخش باغ"
        verbose_name_plural = "بخش‌های باغ"
############################################################3
class VisitRoute(models.Model):
    title = models.CharField(max_length=255, verbose_name="عنوان مسیر")
    description = models.TextField(verbose_name="توضیحات")
    route_map = models.ImageField(upload_to='visit_routes/', null=True, blank=True, verbose_name="نقشه مسیر")
    route_file=models.FileField(upload_to='visite_route/files/', null=True, blank=True, verbose_name="فایل مسیر (PDF)")

    def __str__(self):
        return self.title

    class Meta:
        verbose_name = "مسیر بازدید"
        verbose_name_plural = "مسیرهای بازدید"
##################################################################
class VisitorGroup(models.Model):
    GROUP_CHOICES = [
        ('عموم', 'عموم'),
        ('گروه/دانشجویی', 'گروه/دانشجویی'),
        ('خارجی', 'خارجی'),
    ]

    name = models.CharField(max_length=50, choices=GROUP_CHOICES, unique=True, verbose_name="گروه بازدیدکننده")

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = "گروه بازدیدکننده"
        verbose_name_plural = "گروه‌های بازدیدکننده"
#####################################################################
class Place(models.Model):
    title = models.CharField(max_length=255, verbose_name="عنوان مکان")
    main_image = models.ImageField(upload_to='places/', verbose_name="تصویر اصلی")
    visiting_hours = models.CharField(max_length=255, verbose_name="ساعت بازدید")
    visiting_days = models.CharField(max_length=255, verbose_name="روزهای بازدید")
    rules = models.TextField(verbose_name="قوانین و مقررات")
    more_info = models.TextField(null=True, blank=True, verbose_name="اطلاعات بیشتر")
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="تاریخ ثبت مکان")

    def __str__(self):
        return self.title

    class Meta:
        verbose_name = "مکان بازدید"
        verbose_name_plural = "مکان‌های بازدید"
#######################################################################
class TicketPrice(models.Model):
    visitor_group = models.ForeignKey(VisitorGroup, on_delete=models.CASCADE, verbose_name="گروه بازدیدکننده")
    place = models.ForeignKey(Place, on_delete=models.CASCADE, verbose_name="مکان بازدید")
    price = models.DecimalField(max_digits=10, decimal_places=2, verbose_name="قیمت بلیط")

    def __str__(self):
        return f"{self.visitor_group.name} - {self.place.title}: {self.price} تومان"

    class Meta:
        verbose_name = "بهای بلیط"
        verbose_name_plural = "بهای بلیط‌ها"
########################################################################
class Message(models.Model):
    name = models.CharField(max_length=255, verbose_name="نام و نام خانوادگی")
    email = models.EmailField(verbose_name="ایمیل")
    subject = models.CharField(max_length=255, verbose_name="موضوع پیام")
    message = models.TextField(verbose_name="متن پیام")
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="تاریخ ثبت پیام")
    is_seen = models.BooleanField(default=False, verbose_name="وضعیت مشاهده")

    def __str__(self):
        return f"{self.name} - {self.subject}"

    class Meta:
        verbose_name = "پیغام تماس"
        verbose_name_plural = "پیغام‌های تماس"
###################################################################################
