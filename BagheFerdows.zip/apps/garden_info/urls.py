from django.urls import path
from . import views as views

urlpatterns = [
    path('history/', views.history_view, name='history'),
    path('sections/', views.garden_sections_view, name='sections'),
    path('visit-route/', views.visit_route_view, name='visit_route'),
    path('visit-info/', views.visit_info_view, name='visit_info'),
    path('contact/', views.contact_view, name='contact'),
]
