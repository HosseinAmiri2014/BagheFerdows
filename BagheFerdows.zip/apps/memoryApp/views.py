from django.shortcuts import render

from django.views.generic import CreateView, ListView, DetailView
from django.contrib.auth.mixins import LoginRequiredMixin
from django.shortcuts import get_object_or_404
from django.http import JsonResponse
from .models import Memory, MemoryGallery, MemoryLike
from .forms import MemoryForm, MemoryGalleryFormSet

class MemoryListView(LoginRequiredMixin, ListView):
    model = Memory
    template_name = 'memoryApp/memory_list.html'
    context_object_name = 'memories'

    def get_queryset(self):
        return Memory.objects.filter(is_active=True).order_by('-created_at')

class MemoryDetailView(LoginRequiredMixin, DetailView):
    model = Memory
    template_name = 'memoryApp/memory_detail.html'
    context_object_name = 'memory'

class MemoryCreateView(LoginRequiredMixin, CreateView):
    model = Memory
    form_class = MemoryForm
    template_name = 'memoryApp/memory_create.html'

    def form_valid(self, form):
        form.instance.user = self.request.user
        response = super().form_valid(form)
        gallery_form = MemoryGalleryFormSet(self.request.POST, self.request.FILES, instance=self.object)
        if gallery_form.is_valid():
            gallery_form.save()
        return response

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['formset'] = MemoryGalleryFormSet()
        return context

# Ajax view for like
from django.views.decorators.http import require_POST
from django.contrib.auth.decorators import login_required

@require_POST
@login_required
def like_memory(request, pk):
    memory = get_object_or_404(Memory, pk=pk)
    liked, created = MemoryLike.objects.get_or_create(user=request.user, memory=memory)
    if not created:
        liked.delete()
        return JsonResponse({'liked': False, 'total_likes': memory.likes.count()})
    return JsonResponse({'liked': True, 'total_likes': memory.likes.count()})
