from django.db import models
from django.contrib.auth.models import User
from django.utils.timezone import now

class Memory(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name="کاربر")
    title = models.CharField(max_length=255, verbose_name="عنوان خاطره")
    memory_date = models.DateField(verbose_name="تاریخ خاطره")
    content = models.TextField(verbose_name="متن خاطره")
    main_image = models.ImageField(upload_to='memories/main/', null=True, blank=True, verbose_name="تصویر اصلی")
    created_at = models.DateTimeField(default=now, verbose_name="تاریخ ثبت خاطره")
    is_active = models.BooleanField(default=True, verbose_name="وضعیت فعال")

    def __str__(self):
        return self.title

class MemoryGallery(models.Model):
    memory = models.ForeignKey(Memory, on_delete=models.CASCADE, related_name='gallery')
    image = models.ImageField(upload_to='memories/gallery/', verbose_name="تصویر")

    def __str__(self):
        return f"تصویر برای خاطره: {self.memory.title}"

class MemoryLike(models.Model):
    memory = models.ForeignKey(Memory, on_delete=models.CASCADE, related_name='likes')
    user = models.ForeignKey(User, on_delete=models.CASCADE)

    class Meta:
        unique_together = ('memory', 'user')
