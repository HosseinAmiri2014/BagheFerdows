from django.contrib import admin
from .models import Memory, MemoryGallery, MemoryLike

class MemoryGalleryInline(admin.TabularInline):
    model = MemoryGallery
    extra = 1

@admin.register(Memory)
class MemoryAdmin(admin.ModelAdmin):
    list_display = ('title', 'user', 'memory_date', 'is_active')
    inlines = [MemoryGalleryInline]

admin.site.register(MemoryLike)
