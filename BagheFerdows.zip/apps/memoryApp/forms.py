from django import forms
from .models import Memory, MemoryGallery
from django.forms import modelformset_factory

class MemoryForm(forms.ModelForm):
    class Meta:
        model = Memory
        fields = ['title', 'memory_date', 'content', 'main_image']

MemoryGalleryFormSet = modelformset_factory(
    MemoryGallery,
    fields=('image',),
    extra=3,
    max_num=5,
    can_delete=True
)