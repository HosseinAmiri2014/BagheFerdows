from django.urls import path
from .views import MemoryListView, MemoryDetailView, MemoryCreateView, like_memory

urlpatterns = [
    path('', MemoryListView.as_view(), name='memory_list'),
    path('new/', MemoryCreateView.as_view(), name='memory_create'),
    path('<int:pk>/', MemoryDetailView.as_view(), name='memory_detail'),
    path('<int:pk>/like/', like_memory, name='memory_like'),
]