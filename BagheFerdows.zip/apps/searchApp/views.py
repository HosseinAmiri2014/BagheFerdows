from django.shortcuts import render
from django.db.models import Q
from apps.memoryApp.models import Memory
from apps.blogApp.models import Article, Author
from apps.garden_info.models import GardenSection


def search_view(request):
    query = request.GET.get('q', '').strip()
    
    
    memory_results =[]
    article_results =[]
    section_results = []
    workshop_results = []

    if query:
        memory_results = Memory.objects.filter(
            Q(title__icontains=query) | Q(content__icontains=query),
            is_active=True
        )

        article_results = Article.objects.filter(
            Q(title__icontains=query) | Q(abstract__icontains=query) | Q(short_text__icontains=query),
            # status=True
        )

        section_results = GardenSection.objects.filter(
            Q(name__icontains=query) | Q(description__icontains=query)
        )

        workshop_results = Author.objects.filter(
            Q(first_name__icontains=query) | Q(last_name__icontains=query) | Q(education__icontains=query),
            is_active=True
        )

    context = {
        'query': query,
        'memory_results': memory_results,
        'article_results': article_results,
        'section_results': section_results,
        'author_results': workshop_results,
    }
    return render(request, 'searchApp/search_results.html', context)
