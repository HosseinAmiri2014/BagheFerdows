from django.db import models
from PIL import Image

# Create your models here.
class SiteInfo(models.Model):
    site_name = models.CharField(max_length=255, verbose_name="نام سایت")
    site_description = models.TextField(verbose_name="توضیحات سایت")
    address = models.TextField(verbose_name="آدرس")
    phone = models.CharField(max_length=20, verbose_name="شماره تماس")
    email = models.EmailField(verbose_name="ایمیل")
    logo = models.ImageField(upload_to='site_logo/', verbose_name="لوگوی سایت", null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="تاریخ ثبت")

    def __str__(self):
        return self.site_name

    class Meta:
        verbose_name = "اطلاعات سایت"
        verbose_name_plural = "اطلاعات سایت"


#########
class HomeSlider(models.Model):
    title = models.CharField(max_length=255, verbose_name="عنوان اسلاید")
    subtitle = models.CharField(max_length=255, verbose_name="زیرنویس", null=True, blank=True)
    image = models.ImageField(upload_to='home_slider/', verbose_name="تصویر اسلایدر")
    link = models.URLField(verbose_name="لینک مرتبط", null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="تاریخ ثبت")

    def save(self,*args, **kwarg):
        super().save(*args, **kwarg)
        
        
        img=Image.open(self.image.path)
        img=img.resize((400,400), Image.ANTIALIAS)
        img.save(self.image.path)
    
    def __str__(self):
        return self.title

    class Meta:
        verbose_name = "اسلایدر صفحه اصلی"
        verbose_name_plural = "اسلایدر صفحه اصلی"
#################

class MainMenu(models.Model):
    title = models.CharField(max_length=255, verbose_name="عنوان منو")
    url = models.CharField(max_length=255, verbose_name="لینک منو")
    order = models.PositiveIntegerField(default=0, verbose_name="ترتیب نمایش")
    parent = models.ForeignKey('self', on_delete=models.CASCADE, null=True, blank=True, related_name='submenus', verbose_name="منوی والد")

    def __str__(self):
        return self.title

    class Meta:
        ordering = ['order']
        verbose_name = "منوی اصلی"
        verbose_name_plural = "منوهای اصلی"
##############
class FooterInfo(models.Model):
    copyright_text = models.CharField(max_length=255, verbose_name="متن کپی‌رایت")
    social_links = models.JSONField(verbose_name="لینک‌های شبکه‌های اجتماعی", default=dict)  # {"instagram": "url", "twitter": "url"}

    def __str__(self):
        return "تنظیمات فوتر سایت"

    class Meta:
        verbose_name = "اطلاعات فوتر"
        verbose_name_plural = "اطلاعات فوتر"
#####################
class UserMessage(models.Model):
    name = models.CharField(max_length=255, verbose_name="نام و نام خانوادگی")
    email = models.EmailField(verbose_name="ایمیل")
    subject = models.CharField(max_length=255, verbose_name="موضوع پیام")
    message = models.TextField(verbose_name="متن پیام")
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="تاریخ ارسال پیام")
    is_seen = models.BooleanField(default=False, verbose_name="وضعیت مشاهده")

    def __str__(self):
        return f"{self.name} - {self.subject}"

    class Meta:
        verbose_name = "پیام کاربران"
        verbose_name_plural = "پیام‌های کاربران"