from django.contrib import admin

# Register your models here.
from django.contrib import admin
from .models import SiteInfo, HomeSlider, MainMenu, FooterInfo, UserMessage

admin.site.register(SiteInfo)
admin.site.register(HomeSlider)
admin.site.register(MainMenu)
admin.site.register(FooterInfo)
admin.site.register(UserMessage)
