from django.shortcuts import render
from django.conf import settings 
from .models import HomeSlider




def home(request):
    sliders=HomeSlider.objects.all()
    return render(request, 'mainApp/index.html',{'sliders':sliders})


def media_admin(request):
    return {'media_url':settings.MEDIA_URL,}



